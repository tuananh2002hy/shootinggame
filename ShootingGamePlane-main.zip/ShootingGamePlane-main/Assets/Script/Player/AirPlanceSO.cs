using UnityEngine;

namespace Script
{
    [System.Serializable]
    public class AirPlanceSo
    {
        public int idAirPlane;
        public Sprite sprite;
        public RuntimeAnimatorController animator;
    }
}
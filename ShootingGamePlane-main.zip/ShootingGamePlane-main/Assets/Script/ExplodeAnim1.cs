using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ExplodeAnim1 : MonoBehaviour
{
    public void DisableAnimationExplode()
    {
        gameObject.SetActive(false);
    }
}
